PDF Splitter (FastAPI + Frontend)

This project provides a reliable server that accepts large PDF uploads, splits by page, and returns a ZIP of the split PDFs. It is designed for deployment to Render (recommended) or any other provider that runs Docker / Python web services.

Key features:
- Chunked upload support (client-side) for reliability
- Server-side splitting using pypdf (quality preserved)
- Streaming ZIP download
- Temporary file cleanup
- Optional S3 integration (commented) for large-scale storage
- PWA-friendly static frontend
