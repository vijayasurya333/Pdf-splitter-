from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, StreamingResponse, HTMLResponse
import shutil
import os
import uuid
import zipfile
from pathlib import Path
from pypdf import PdfReader, PdfWriter
import aiofiles
import asyncio
import time

app = FastAPI()

BASE_DIR = Path(__file__).parent
TMP_DIR = BASE_DIR / 'tmp'
TMP_DIR.mkdir(exist_ok=True)

MAX_UPLOAD_SIZE = 2_000_000_000

async def save_upload_file_tmp(upload_file: UploadFile, destination: Path) -> int:
    size = 0
    async with aiofiles.open(destination, 'wb') as out_file:
        while True:
            chunk = await upload_file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_UPLOAD_SIZE:
                raise HTTPException(status_code=413, detail='File too large')
            await out_file.write(chunk)
    return size

@app.get('/', response_class=HTMLResponse)
async def index():
    html_file = BASE_DIR / 'static' / 'index.html'
    return HTMLResponse(html_file.read_text(encoding='utf-8'))

@app.post('/upload')
async def upload(file: UploadFile = File(...)):
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail='Only PDF files are allowed')

    uid = uuid.uuid4().hex
    upload_dir = TMP_DIR / uid
    upload_dir.mkdir(parents=True, exist_ok=True)
    saved_path = upload_dir / file.filename

    size = await save_upload_file_tmp(file, saved_path)

    return {"job_id": uid, "filename": file.filename, "size": size}

@app.post('/split_by_pages')
async def split_by_pages(job_id: str, start_page: int = None, end_page: int = None, background_tasks: BackgroundTasks = None):
    upload_dir = TMP_DIR / job_id
    if not upload_dir.exists():
        raise HTTPException(status_code=404, detail='Job not found')
    files = list(upload_dir.glob('*.pdf'))
    if not files:
        raise HTTPException(status_code=404, detail='PDF not found')
    pdf_path = files[0]

    out_dir = upload_dir / 'output'
    out_dir.mkdir(exist_ok=True)

    reader = PdfReader(str(pdf_path))
    total_pages = len(reader.pages)

    s = start_page or 1
    e = end_page or total_pages
    if s < 1 or e > total_pages or s > e:
        raise HTTPException(status_code=400, detail='Invalid page range')

    for i in range(s - 1, e):
        writer = PdfWriter()
        writer.add_page(reader.pages[i])
        out_file = out_dir / f"{pdf_path.stem}_p{i+1}.pdf"
        with open(out_file, 'wb') as f:
            writer.write(f)

    zip_path = upload_dir / f"{pdf_path.stem}_split_{s}_{e}.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for p in sorted(out_dir.glob('*.pdf')):
            zipf.write(p, arcname=p.name)

    return {"download_url": f"/download/{job_id}/{zip_path.name}", "pages": total_pages}

@app.get('/download/{job_id}/{zip_name}')
async def download(job_id: str, zip_name: str):
    zip_path = TMP_DIR / job_id / zip_name
    if not zip_path.exists():
        raise HTTPException(status_code=404, detail='File not found')
    return FileResponse(path=str(zip_path), filename=zip_name, media_type='application/zip')

@app.post('/cleanup')
async def cleanup(job_id: str):
    upload_dir = TMP_DIR / job_id
    if not upload_dir.exists():
        return {"status": "not found"}

    def rmtree(p: Path):
        for child in p.iterdir():
            if child.is_file():
                child.unlink()
            else:
                rmtree(child)
        p.rmdir()

    rmtree(upload_dir)
    return {"status": "deleted"}

@app.on_event("startup")
async def schedule_cleanup():
    async def cleaner():
        while True:
            now = time.time()
            for d in TMP_DIR.iterdir():
                try:
                    mtime = d.stat().st_mtime
                    if now - mtime > 6 * 3600:
                        def rmtree2(p: Path):
                            for child in p.iterdir():
                                if child.is_file():
                                    child.unlink()
                                else:
                                    rmtree2(child)
                            p.rmdir()
                        rmtree2(d)
                except Exception:
                    pass
            await asyncio.sleep(3600)
    asyncio.create_task(cleaner())
