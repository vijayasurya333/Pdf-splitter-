const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');
const progress = document.getElementById('progress');
const percent = document.getElementById('percent');
const controls = document.getElementById('controls');
const splitBtn = document.getElementById('splitBtn');
const result = document.getElementById('result');
const downloadLink = document.getElementById('downloadLink');
const logs = document.getElementById('logs');

let currentJob = null;
let uploadedFilename = null;

uploadBtn.onclick = async () => {
  const file = fileInput.files[0];
  if (!file) { alert('Choose a PDF'); return }
  if (!file.name.toLowerCase().endsWith('.pdf')) { alert('Not a PDF'); return }

  progress.classList.remove('hidden');
  percent.innerText = '0%';
  logs.innerText = '';

  const form = new FormData();
  form.append('file', file, file.name);
  try {
    const resp = await fetch('/upload', {method: 'POST', body: form});
    if (!resp.ok) throw new Error('Upload failed ' + resp.status);
    const data = await resp.json();
    currentJob = data.job_id;
    uploadedFilename = data.filename;
    logs.innerText = `Uploaded ${data.filename} (${Math.round(data.size/1024/1024)} MB)`;
    controls.classList.remove('hidden');
  } catch (e) {
    alert('Upload error: ' + e.message);
    logs.innerText = 'Upload error: ' + e.message;
  } finally {
    progress.classList.add('hidden');
  }
}

splitBtn.onclick = async () => {
  if (!currentJob) return alert('Upload first');
  const start = parseInt(document.getElementById('startPage').value) || null;
  const end = parseInt(document.getElementById('endPage').value) || null;

  const body = new URLSearchParams();
  body.append('job_id', currentJob);
  if (start) body.append('start_page', start);
  if (end) body.append('end_page', end);

  try {
    const resp = await fetch('/split_by_pages', {method: 'POST', body});
    if (!resp.ok) throw new Error('Split failed ' + resp.status);
    const data = await resp.json();
    const downloadUrl = data.download_url;
    downloadLink.href = downloadUrl;
    downloadLink.innerText = 'Download ZIP (' + uploadedFilename + ')';
    result.classList.remove('hidden');
    logs.innerText = `Split complete: ${data.pages} pages available`;
  } catch (e) {
    alert('Split error: ' + e.message);
    logs.innerText = 'Split error: ' + e.message;
  }
}

downloadLink.onclick = (e) => {}
